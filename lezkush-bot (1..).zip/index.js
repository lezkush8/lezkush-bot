const axios = require('axios');
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

const API_KEY = process.env.API_KEY || '91e81920';
const BOT_NAME = process.env.BOT_NAME || '✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧';

app.use(express.json());

app.post('/webhook', async (req, res) => {
  const message = req.body.message || '';
  if (message.startsWith('.movie')) {
    const movieName = message.replace('.movie', '').trim();
    if (!movieName) return res.send({ reply: 'Please provide a movie title.' });

    try {
      const response = await axios.get(\`http://www.omdbapi.com/?t=\${encodeURIComponent(movieName)}&apikey=\${API_KEY}\`);
      const data = response.data;
      if (data.Response === 'False') {
        return res.send({ reply: 'Movie not found.' });
      }

      const reply = \`🎬 *\${data.Title}* (\${data.Year})
⭐ Rating: \${data.imdbRating}
📽 Genre: \${data.Genre}
🧑‍🎤 Actors: \${data.Actors}
📝 Plot: \${data.Plot}

🤖 Powered by \${BOT_NAME}\`;

      return res.send({ reply });
    } catch (error) {
      return res.send({ reply: 'An error occurred while fetching movie details.' });
    }
  } else {
    return res.send({ reply: 'Command not recognized.' });
  }
});

app.get('/', (req, res) => res.send('Bot is running.'));
app.listen(PORT, () => console.log(\`Bot running on port \${PORT}\`));
