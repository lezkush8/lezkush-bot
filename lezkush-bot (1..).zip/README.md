# ✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧ – WhatsApp Bot

A simple WhatsApp bot built using Node.js and Express. Use `.movie` command to search for movies.

## Commands

- `.movie <movie title>` – Get movie information from OMDb API.

## Environment Variables (Heroku)

- `API_KEY`: Your OMDb API Key (default: `91e81920`)
- `BOT_NAME`: Your Bot's Name (e.g. ✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧)
