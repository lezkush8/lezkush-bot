# ✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧

A WhatsApp bot that fetches movie data using the `.movie` command.