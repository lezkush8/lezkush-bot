# ✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧

A WhatsApp bot that responds to `.movie` commands using OMDB API.

## Usage
Send a message in the format `.movie movie name` and get movie details.

## Hosted on
Heroku