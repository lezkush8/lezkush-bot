const express = require("express");
const axios = require("axios");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post("/webhook", async (req, res) => {
    const body = req.body;
    if (!body.message || !body.message.text) return res.sendStatus(200);

    const messageText = body.message.text;
    if (messageText.startsWith(".movie")) {
        const movieName = messageText.replace(".movie", "").trim();
        if (!movieName) {
            return res.json({ reply: "Please provide a movie name." });
        }

        try {
            const response = await axios.get(`http://www.omdbapi.com/?t=${encodeURIComponent(movieName)}&apikey=91e81920`);
            const data = response.data;

            if (data.Response === "False") {
                return res.json({ reply: "Movie not found." });
            }

            const replyMessage = `🎬 *${data.Title}* (${data.Year})\n⭐ *IMDb:* ${data.imdbRating}\n📖 *Plot:* ${data.Plot}\n🎭 *Genre:* ${data.Genre}\n🎬 *Director:* ${data.Director}`;
            return res.json({ reply: replyMessage });
        } catch (error) {
            return res.json({ reply: "Error fetching movie details." });
        }
    }

    res.sendStatus(200);
});

app.listen(PORT, () => {
    console.log(`Bot running on port ${PORT}`);
});