# ✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧ - WhatsApp Bot

A basic WhatsApp bot using `whatsapp-web.js` and OMDb API.

### 🚀 How to use
1. Run `npm install`
2. Start the bot: `npm start`
3. Scan the QR code on WhatsApp Web
4. Send message like: `movie Avengers`

### 📦 Powered by
- OMDb API
- WhatsApp Web.js
