const { Client } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const axios = require('axios');

const client = new Client();

client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('Lezkush Bot is ready!');
});

client.on('message', async message => {
    if (message.body.toLowerCase().startsWith('movie')) {
        const query = message.body.split(' ').slice(1).join(' ');
        try {
            const response = await axios.get(`http://www.omdbapi.com/?apikey=91e81920&t=${encodeURIComponent(query)}`);
            const data = response.data;
            if (data.Response === "True") {
                const reply = `🎬 *${data.Title}* (${data.Year})
⭐ ${data.imdbRating}/10
📖 ${data.Plot}`;
                message.reply(reply);
            } else {
                message.reply('Movie not found!');
            }
        } catch (err) {
            message.reply('Error fetching data.');
        }
    }
});

client.initialize();
