*✧𝐿𝛯𝛧𝛫𝑈𝑆𝛨 𝐵𝛩𝑇✧ BOT INFO*  
❒───────────────────❒

*GITHUB LINK*  
> https://github.com/lezkush8/lezkush-bot

*CONTACT OWNER*  
> https://wa.me/96878856800

*WHATSAPP CHANNEL*  
> https://whatsapp.com/channel/0029VavrEpMGk1FwLHTpXZ39

╭───────────────────❒  
 │❒⁠⁠⁠⁠ *RAM* : 21.68 GB/61.79 GB  
 │❒⁠⁠⁠⁠ *DEV1* : *𝐋𝚵𝚭𝐊𝐔𝐒𝚮-𝚻𝚳𝐃*  
 │❒⁠⁠⁠⁠ *DEV2* : *𝐋𝚵𝚭𝐊𝐔𝐒𝚮-𝚻𝚳𝐃*  
╰───────────────────❒  

        *ᵖᵒʷᵉʳ ᵇʸ ˡᵉᶻᵏᵘˢʰ*  

❒───────────────────❒
